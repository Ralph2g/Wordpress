<?php

/**
 * Description of BNotificationBus
 *
 * @author nur
 */
class SwpmNotificationBus {
    
}
