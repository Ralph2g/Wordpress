<?php

/*** TODO - This file exists for backwards compatibility only. Remove it at a later date. ***/
class miscUtils extends SwpmMiscUtils {

}

class BUtils extends SwpmUtils {

}

class BMemberUtils extends SwpmMemberUtils {

}

class BSettings extends SwpmSettings {

}

class BProtection extends SwpmProtection {

}

class BPermission extends SwpmPermission {

}

class BAuth extends SwpmAuth {

}

class BAccessControl extends SwpmAccessControl {

}

class BForm extends SwpmForm {

}

class BTransfer extends SwpmTransfer {

}

class BFrontForm extends SwpmFrontForm {

}

class BLevelForm extends SwpmLevelForm {

}

class BMembershipLevels extends SwpmMembershipLevels {

}

class BLog extends SwpmLog {

}

class BMessages extends SwpmMessages {

}

class BAjax extends SwpmAjax {

}

class BRegistration extends SwpmRegistration {

}

class BFrontRegistration extends SwpmFrontRegistration {

}

class BAdminRegistration extends SwpmAdminRegistration {

}

class BMembershipLevel extends SwpmMembershipLevel {

}

class BMembershipLevelCustom extends SwpmMembershipLevelCustom {

}

class BMembershipLevelUtils extends SwpmMembershipLevelUtils {

}

class BPermissionCollection extends SwpmPermissionCollection {

}

class BAuthPermissionCollection extends SwpmAuthPermissionCollection {

}

class BTransactions extends SwpmTransactions {

}
