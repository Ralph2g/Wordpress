<div class="notice notice-info">
	<p><strong>Welcome to BeTheme</strong></p>
	<p>Please <a href="admin.php?page=betheme">register</a> this version of theme to get access to pre-built websites, premium bundled plugins and auto updates.</p>
	<p><strong>Important!</strong> One <a target="_blank" href="https://themeforest.net/licenses/standard">standard license</a> is valid only for <strong>1 website</strong>. Running multiple websites on a single license is a copyright violation.</p>
</div>